package com.third_week;

public class methodOverloading {
    static void sum(){

    }
    static void sum(int a, int b){

    }
    static void sum(double a, double b){

    }


}
