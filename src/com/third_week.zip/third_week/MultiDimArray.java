package com.third_week;

public class MultiDimArray {
    public static void main(String[] args) {
        int [][] arr = {{1,2,3,4}, {5,6,7}, {8,9,10}};

        //System.out.println(arr[1][2]);
        for (int i = 0; i < arr.length ; i++) {

            for (int j = 0; j < arr[i].length; j++) {
                System.out.println(arr[i][j]);



            }

        }

    }
}
