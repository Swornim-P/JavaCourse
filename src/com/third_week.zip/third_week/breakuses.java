package com.third_week;

public class breakuses {
    public static void main(String[] args) {
//        for (int i = 0; i <=10 ; i++) {
//            if (i==5){
//                continue;
//            }
//            System.out.println(i);
//
//
//        }
        for (int i = 0; i <= 50 ; i++) {
            if (i%2 == 0){
                continue;
            }
            System.out.println(i);

        }
    }
}
